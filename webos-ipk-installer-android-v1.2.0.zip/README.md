
# webOS IPK Installer — Android App (v1.2.0)

Native Android app to install `.ipk` on rooted LG webOS TVs via **Homebrew Channel**:

- Embedded HTTP server (NanoHTTPD) serves IPKs: http://<phone_ip>:8866
- SSHJ executes:
  `luna-send -i -f luna://org.webosbrew.hbchannel.service/install '{"ipkUrl":"...","ipkHash":"<sha256>","subscribe":true}'`
- Device discovery (scan /24 for SSH)
- Progress UI that parses `progress` / `percent` from subscribe output
- Sandbox mode (no network; simulated progress)

## Build
Open in **Android Studio** and hit Run. Or CI:

```
./gradlew assembleRelease
```

## Sources
- Homebrew Channel / luna-send usage: see webOS Homebrew docs
- NanoHTTPD embedded server
- SSHJ library
