package com.dev1337.webosinstaller.server

import android.app.*
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

data class FileMeta(val name: String)

object LocalRepo {
    private val map = ConcurrentHashMap<String, Uri>()
    val meta = ConcurrentHashMap<String, FileMeta>()

    fun register(uri: Uri, name: String, cr: ContentResolver): String {
        val token = android.util.Base64.encodeToString((name + "|" + uri.toString()).toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
        map[token] = uri
        meta[token] = FileMeta(name)
        return token
    }

    fun open(token: String, cr: ContentResolver): Pair<InputStream, FileMeta>? {
        val uri = map[token] ?: return null
        val m = meta[token] ?: FileMeta("file")
        val stream = cr.openInputStream(uri) ?: return null
        return stream to m
    }

    fun sha256(token: String, cr: ContentResolver): String {
        val pair = open(token, cr) ?: return ""
        pair.first.use { input ->
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(1 shl 15)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }
    }
}

class SimpleHttpServer(private val ctx: Context): NanoHTTPD(8866) {
    override fun serve(session: IHTTPSession): Response {
        return try {
            val uri = session.uri
            if (uri.startsWith("/files/")) {
                val token = uri.removePrefix("/files/")
                val pair = LocalRepo.open(token, ctx.contentResolver)
                if (pair == null) newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
                else {
                    val (stream, meta) = pair
                    newChunkedResponse(Response.Status.OK, "application/vnd.debian.binary-package", stream)
                }
            } else if (uri == "/health") {
                newFixedLengthResponse("OK")
            } else {
                newFixedLengthResponse("webOS IPK Installer server up")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "ERR: ${e.message}")
        }
    }
}

class ForegroundServerService: Service() {
    private var server: SimpleHttpServer? = null
    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        server = SimpleHttpServer(this)
        server?.start()

        val channelId = "ipkserver"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "IPK Server", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("webOS IPK Server running")
            .setContentText("Serving on port 8866")
            .build()
        ServiceCompat.startForeground(this, 1, notif, android.os.Build.VERSION.SDK_INT >= 34)
    }

    override fun onDestroy() {
        super.onDestroy()
        server?.stop()
        server = null
    }

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, ForegroundServerService::class.java)
            ctx.startForegroundService(i)
        }
        fun stop(ctx: Context) {
            val i = Intent(ctx, ForegroundServerService::class.java)
            ctx.stopService(i)
        }
    }
}