package com.dev1337.webosinstaller.server

object SandboxInstaller {
    fun runFake(onLine: (String)->Unit): Int {
        for (p in listOf(0, 10, 25, 40, 55, 70, 85, 100)) {
            onLine("{\"status\":\"downloading\",\"progress\":$p}")
            try { Thread.sleep(400) } catch (_: InterruptedException) {}
        }
        onLine("{\"finished\": true}")
        return 0
    }
}