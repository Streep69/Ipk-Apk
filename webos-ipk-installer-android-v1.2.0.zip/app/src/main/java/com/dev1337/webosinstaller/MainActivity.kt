package com.dev1337.webosinstaller

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import com.dev1337.webosinstaller.server.*
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var txtLocalIp: TextView
    private lateinit var txtLogs: TextView
    private lateinit var inputTvIp: EditText
    private lateinit var inputUser: EditText
    private lateinit var inputPort: EditText
    private lateinit var listContainer: LinearLayout
    private lateinit var chkSandbox: CheckBox

    private val picked = ConcurrentHashMap<String, Uri>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtLocalIp = findViewById(R.id.txtLocalIp)
        txtLogs = findViewById(R.id.txtLogs)
        inputTvIp = findViewById(R.id.inputTvIp)
        inputUser = findViewById(R.id.inputUser)
        inputPort = findViewById(R.id.inputPort)
        listContainer = findViewById(R.id.listContainer)
        chkSandbox = findViewById(R.id.chkSandbox)

        txtLocalIp.text = "Local IP: ${NetUtils.localWifiIp(this) ?: "unknown"}:8866"

        findViewById<Button>(R.id.btnStartServer).setOnClickListener {
            ForegroundServerService.start(this)
            toast("Server started on port 8866")
        }
        findViewById<Button>(R.id.btnStopServer).setOnClickListener {
            ForegroundServerService.stop(this)
            toast("Server stopped")
        }
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickFiles() }
        findViewById<Button>(R.id.btnDiscover).setOnClickListener { discoverTvs() }
        findViewById<Button>(R.id.btnInstallAll).setOnClickListener { installAll() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 1337)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1337 && resultCode == Activity.RESULT_OK) {
            picked.clear()
            data?.let { intent ->
                val clip: ClipData? = intent.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) {
                        clip.getItemAt(i).uri?.let { addPicked(it) }
                    }
                } else {
                    intent.data?.let { addPicked(it) }
                }
            }
            renderPicked()
        }
    }

    private fun addPicked(uri: Uri) {
        val name = displayName(uri) ?: uri.lastPathSegment ?: "ipk"
        val token = LocalRepo.register(uri, name, contentResolver)
        picked[token] = uri
    }

    private fun displayName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && nameIdx >= 0) name = c.getString(nameIdx)
        }
        return name
    }

    private fun renderPicked() {
        listContainer.removeAllViews()
        for ((token, uri) in picked.entries) {
            val name = LocalRepo.meta[token]?.name ?: "file"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(8)
            }
            val tv = TextView(this).apply { text = "• $name\n  token=$token" }
            row.addView(tv)

            val prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
            row.addView(prog)

            val btnSha = Button(this).apply { text = "Compute SHA-256" }
            btnSha.setOnClickListener {
                scope.launch(Dispatchers.IO) {
                  val sha = LocalRepo.sha256(token, contentResolver)
                  withContext(Dispatchers.Main) { appendLog("$name SHA-256: $sha") }
                }
            }
            row.addView(btnSha)

            val btnInstall = Button(this).apply { text = getString(R.string.install) }
            btnInstall.setOnClickListener {
                val ip = inputTvIp.text.toString().trim()
                val user = inputUser.text.toString().trim().ifEmpty { "root" }
                val port = inputPort.text.toString().trim().toIntOrNull() ?: 22
                val sandbox = chkSandbox.isChecked

                scope.launch(Dispatchers.IO) {
                    val sha = LocalRepo.sha256(token, contentResolver)
                    val localIp = NetUtils.localWifiIp(this@MainActivity) ?: "127.0.0.1"
                    val url = "http://$localIp:8866/files/$token"
                    val payload = "{\"ipkUrl\":\"$url\",\"ipkHash\":\"$sha\",\"subscribe\":true}"
                    appendLog("Installing $name\n  URL: $url\n  SHA: $sha")
                    val rc = if (sandbox) {
                        SandboxInstaller.runFake { line ->
                            appendLog(line)
                            parseProgress(line)?.let { p -> runOnUiThread { prog.progress = p } }
                        }
                    } else {
                        SshInstaller.exec(ip, port, user,
                            "luna-send -i -f luna://org.webosbrew.hbchannel.service/install '$payload'"
                        ) { line ->
                            appendLog(line)
                            parseProgress(line)?.let { p -> runOnUiThread { prog.progress = p } }
                        }
                    }
                    appendLog(if (rc == 0) "Install finished (rc=0)" else "Install failed (rc=$rc)")
                }
            }
            row.addView(btnInstall)

            listContainer.addView(row)
        }
    }

    private fun parseProgress(line: String): Int? {
        // crude JSON percent extractor: look for "progress": 0-100 or "percent"
        val regex = Regex("\"(progress|percent)\"\\s*:\\s*(\\d{1,3})")
        val m = regex.find(line) ?: return null
        val v = m.groupValues[2].toInt()
        return v.coerceIn(0, 100)
    }

    private fun installAll() {
        if (picked.isEmpty()) { toast("No files selected"); return }
        for ((token, _) in picked.entries) {
            // Find the row view by scanning children for token text
            val count = listContainer.childCount
            for (i in 0 until count) {
                val row = listContainer.getChildAt(i) as LinearLayout
                val tv = row.getChildAt(0) as TextView
                if (tv.text.contains("token=$token")) {
                    val prog = row.getChildAt(1) as ProgressBar
                    startInstallForToken(token, prog)
                    break
                }
            }
        }
    }

    private fun startInstallForToken(token: String, prog: ProgressBar) {
        val name = LocalRepo.meta[token]?.name ?: "file"
        val ip = inputTvIp.text.toString().trim()
        val user = inputUser.text.toString().trim().ifEmpty { "root" }
        val port = inputPort.text.toString().trim().toIntOrNull() ?: 22
        val sandbox = chkSandbox.isChecked

        scope.launch(Dispatchers.IO) {
            val sha = LocalRepo.sha256(token, contentResolver)
            val localIp = NetUtils.localWifiIp(this@MainActivity) ?: "127.0.0.1"
            val url = "http://$localIp:8866/files/$token"
            val payload = "{\"ipkUrl\":\"$url\",\"ipkHash\":\"$sha\",\"subscribe\":true}"
            appendLog("Installing $name\n  URL: $url\n  SHA: $sha")
            val rc = if (sandbox) {
                SandboxInstaller.runFake { line ->
                    appendLog(line)
                    parseProgress(line)?.let { p -> runOnUiThread { prog.progress = p } }
                }
            } else {
                SshInstaller.exec(ip, port, user,
                    "luna-send -i -f luna://org.webosbrew.hbchannel.service/install '$payload'"
                ) { line ->
                    appendLog(line)
                    parseProgress(line)?.let { p -> runOnUiThread { prog.progress = p } }
                }
            }
            appendLog(if (rc == 0) "Install finished (rc=0)" else "Install failed (rc=$rc)")
        }
    }

    private fun discoverTvs() {
        val port = inputPort.text.toString().trim().toIntOrNull() ?: 22
        appendLog("Scanning /24 for port $port…")
        scope.launch(Dispatchers.IO) {
            val ips = Discoverer.scanSubnet(this@MainActivity, port)
            withContext(Dispatchers.Main) {
                if (ips.isEmpty()) toast("No TVs found")
                else {
                    toast("Found: " + ips.joinToString())
                    // Auto-fill the first
                    inputTvIp.setText(ips.first())
                }
            }
        }
    }

    private fun appendLog(line: String) {
        runOnUiThread {
            txtLogs.append(line + "\n")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}