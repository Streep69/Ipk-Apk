package com.dev1337.webosinstaller.server

import android.content.Context
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object Discoverer {
    fun localIpv4(ctx: Context): String? = NetUtils.localWifiIp(ctx)

    fun scanSubnet(ctx: Context, port: Int): List<String> {
        val base = localIpv4(ctx)?.split(".") ?: return emptyList()
        if (base.size != 4) return emptyList()
        val prefix = "${base[0]}.${base[1]}.${base[2]}."
        val pool = Executors.newFixedThreadPool(64)
        val found = ConcurrentLinkedQueue<String>()
        for (i in 1..254) {
            val ip = prefix + i
            pool.execute {
                try {
                    Socket(ip, port).use { s ->
                        s.soTimeout = 300
                        found.add(ip)
                    }
                } catch (_: Exception) { }
            }
        }
        pool.shutdown()
        pool.awaitTermination(5, TimeUnit.SECONDS)
        return found.toList().sorted()
    }
}