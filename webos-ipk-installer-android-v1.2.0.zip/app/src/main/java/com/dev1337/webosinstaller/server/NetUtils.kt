package com.dev1337.webosinstaller.server

import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import java.net.NetworkInterface

object NetUtils {
    fun localWifiIp(ctx: Context): String? {
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val ip = wm.connectionInfo.ipAddress
            if (ip != 0) return Formatter.formatIpAddress(ip)
        } catch (e: Exception) { /* ignore */ }

        // Fallback: iterate interfaces
        val interfaces = NetworkInterface.getNetworkInterfaces()
        for (it in interfaces) {
            val addrs = it.inetAddresses
            for (addr in addrs) {
                val host = addr.hostAddress ?: continue
                if (!addr.isLoopbackAddress && host.indexOf(':') < 0) return host
            }
        }
        return null
    }
}