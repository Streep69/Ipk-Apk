package com.dev1337.webosinstaller.server

import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import net.schmizz.sshj.connection.channel.direct.Session
import java.io.BufferedReader
import java.io.InputStreamReader

object SshInstaller {
    fun exec(host: String, port: Int, user: String, command: String, onLine: (String)->Unit): Int {
        val ssh = SSHClient()
        ssh.addHostKeyVerifier(PromiscuousVerifier())
        ssh.connect(host, port)
        try {
            ssh.authPublickey(user)
        } catch (e: Exception) {
            try { ssh.authPassword(user, "") } catch (e2: Exception) {
                try { ssh.authPassword(user, "alpine") } catch (_: Exception) { /* noop */ }
            }
        }
        val session: Session = ssh.startSession()
        val cmd = session.exec(command)
        val reader = BufferedReader(InputStreamReader(cmd.inputStream))
        var line: String?
        while (reader.readLine().also { line = it } != null) onLine(line!!)
        cmd.join()
        val rc = cmd.exitStatus ?: 1
        session.close(); ssh.disconnect()
        return rc
    }
}